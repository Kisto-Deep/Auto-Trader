The training set for this dataset is the MNIST training set.

This can be loaded in python by using:

```
import tensorflow as tf
(x_train, y_train), _ = tf.keras.datasets.mnist.load_data()
```

It will be up to you to extend a model trained on MNIST to
the test dataset provided.

Good luck!

